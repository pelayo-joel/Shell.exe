#!/bin/bash

file=number_connections_$(date +%d-%m-%Y-'%H:%M')
last | grep $USER | wc -l > $file
tar -cvf ./$file.tar ./ && mv $file.tar Backup
